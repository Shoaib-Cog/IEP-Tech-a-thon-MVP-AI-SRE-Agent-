# SignalOps AI

SignalOps AI is an autonomous incident investigation platform for SRE and infrastructure teams. It ingests PagerDuty alerts, launches specialized agents, collects telemetry and logs, correlates historical patterns, identifies root cause, calculates business impact, recommends remediation, and produces an executive summary.

## Architecture Diagram

```mermaid
flowchart TD
    A[PagerDuty Alert] --> B[SupervisorAgent]
    B --> C[DynatraceAgent]
    B --> D[LogAnalysisAgent]
    B --> E[HistoricalIncidentAgent]
    C --> F[RCAAgent]
    D --> F
    E --> F
    F --> G[ImpactAnalysisAgent]
    G --> H[RemediationAgent]
    F --> I[ExecutiveSummaryAgent]
    I --> J[Incident Dashboard]
    I --> K[Timeline View]
    I --> L[Historical Repository]
```

## Features

- Agentic orchestration using LangGraph-ready workflow
- FastAPI backend with SQLite persistence
- Streamlit dashboard for incident triage
- Dynatrace integration with mock fallback
- Historical incident search and RCA support
- Executive summary generation
- Sample demo data for common outage scenarios

## MVP Scope

This repository implements an MVP with:

- backend incident orchestration API
- mock telemetry provider and real integration adapter
- frontend dashboard
- SQLite schema and seed data
- test coverage for orchestration, RCA, and summary generation

## Folder Structure

```text
signalops-ai/
├── backend/
│   └── app/
│       ├── agents/
│       ├── services/
│       ├── workflows/
│       ├── __init__.py
│       ├── config.py
│       ├── database.py
│       ├── main.py
│       ├── schemas.py
│       └── schema.sql
├── data/
│   ├── incidents/
│   ├── logs/
│   ├── runbooks/
│   ├── historical_incidents.json
│   └── schema.sql
├── frontend/
│   └── app.py
├── tests/
│   ├── test_agents.py
│   └── test_integration.py
├── scripts/
│   ├── setup_windows.ps1
│   ├── setup_macos.sh
│   ├── setup_linux.sh
│   └── start_ollama.ps1
├── docs/
├── .env.example
├── .gitignore
├── README.md
├── requirements.txt
└── venv_setup.md
```

## Quick Start

### 1. Create and activate a Python virtual environment

Windows PowerShell:

```powershell
cd signalops-ai
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Mac/Linux:

```bash
cd signalops-ai
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 2. Start Ollama and pull a model

Windows PowerShell:

```powershell
# Install Ollama from https://ollama.com/download/windows
ollama serve
ollama pull llama3.1
```

Mac:

```bash
brew install ollama
ollama serve
ollama pull llama3.1
```

Linux:

```bash
curl -fsSL https://ollama.com/install.sh | sh
ollama serve
ollama pull llama3.1
```

### 3. Run the backend

```bash
cd signalops-ai
uvicorn backend.app.main:app --reload --host 0.0.0.0 --port 8000
```

### 4. Run the frontend

```bash
cd signalops-ai
streamlit run frontend/app.py --server.port 8501
```

### 5. Run tests

```bash
cd signalops-ai
pytest -q
```

## Configuration

Create a `.env` based on `.env.example`:

```env
DYNATRACE_API_URL=https://your-environment.live.dynatrace.com
DYNATRACE_TOKEN=your-token
PAGERDUTY_API_KEY=your-token
OLLAMA_BASE_URL=http://localhost:11434
MODEL_NAME=llama3.1
APP_ENV=development
```

If credentials are missing, the system automatically uses the mock Dynatrace provider.

## Demo Scenario

PagerDuty Alert: "Payment Service Degraded"

Flow:

1. Alert arrives
2. SupervisorAgent initiates investigation
3. DynatraceAgent gathers telemetry and service health
4. LogAnalysisAgent scans logs for error signatures
5. HistoricalIncidentAgent searches previous incidents
6. RCAAgent correlates the evidence and outputs root cause
7. ImpactAnalysisAgent measures blast radius
8. RemediationAgent recommends corrective steps
9. ExecutiveSummaryAgent emits the final summary

## Screenshots Placeholder

- Dashboard: incident summary cards
- Timeline view: investigation phases
- Executive report: remediation and affected services

## Future Enhancements

- Real PagerDuty API integration
- Real Dynatrace API integration
- Agent memory and long-running workflows
- Slack/Teams notifications
- automated remediation orchestration
- multi-region deployment and alert routing

## License

MIT
