CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    alert_name TEXT NOT NULL,
    service TEXT NOT NULL,
    severity TEXT NOT NULL,
    investigation_status TEXT NOT NULL,
    root_cause TEXT,
    confidence REAL,
    business_impact TEXT,
    recommended_actions TEXT,
    executive_summary TEXT,
    timeline TEXT,
    metadata TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
