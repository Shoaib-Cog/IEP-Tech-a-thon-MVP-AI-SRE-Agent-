import json
import sqlite3
from pathlib import Path
from typing import Any, Dict, List

from .config import DATA_DIR, DB_PATH, INCIDENTS_DIR

SCHEMA = """
CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    alert_name TEXT NOT NULL,
    service TEXT NOT NULL,
    severity TEXT NOT NULL,
    investigation_status TEXT NOT NULL,
    root_cause TEXT,
    confidence REAL,
    business_impact TEXT,
    recommended_actions TEXT,
    executive_summary TEXT,
    timeline TEXT,
    metadata TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def get_connection() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = get_connection()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()
    if not list_incidents():
        seed_incidents()


def seed_incidents() -> None:
    if not INCIDENTS_DIR.exists():
        return
    for incident_path in sorted(INCIDENTS_DIR.glob("*.json")):
        try:
            payload = json.loads(incident_path.read_text(encoding="utf-8"))
            if payload.get("incident_id"):
                save_incident(payload)
        except json.JSONDecodeError:
            continue


def save_incident(record: Dict[str, Any]) -> Dict[str, Any]:
    incident_id = str(record.get("incident_id") or record.get("id") or "PD-UNKNOWN")
    alert_name = str(record.get("alert_name") or record.get("title") or "Unknown Alert")
    service = str(record.get("service") or record.get("affected_service") or "unknown-service")
    severity = str(record.get("severity") or record.get("priority") or "SEV-2")
    status = str(record.get("investigation_status") or record.get("status") or "investigating")
    root_cause = str(record.get("root_cause") or "pending")
    confidence = float(record.get("confidence") or 0.0)
    business_impact = str(record.get("business_impact") or "pending")
    recommended_actions = str(record.get("recommended_actions") or "pending")
    executive_summary = str(record.get("executive_summary") or "pending")
    timeline = json.dumps(record.get("timeline") or [])
    metadata = json.dumps(record.get("metadata") or record)

    conn = get_connection()
    conn.execute(
        """
        INSERT OR REPLACE INTO incidents (
            id, alert_name, service, severity, investigation_status,
            root_cause, confidence, business_impact, recommended_actions,
            executive_summary, timeline, metadata
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            incident_id,
            alert_name,
            service,
            severity,
            status,
            root_cause,
            confidence,
            business_impact,
            recommended_actions,
            executive_summary,
            timeline,
            metadata,
        ),
    )
    conn.commit()
    conn.close()
    return get_incident(incident_id)


def list_incidents() -> List[Dict[str, Any]]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM incidents ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_incident(incident_id: str) -> Dict[str, Any]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM incidents WHERE id = ?", (incident_id,)).fetchone()
    conn.close()
    if not row:
        return {}
    payload = dict(row)
    payload["timeline"] = json.loads(payload.get("timeline") or "[]")
    payload["metadata"] = json.loads(payload.get("metadata") or "{}")
    return payload
