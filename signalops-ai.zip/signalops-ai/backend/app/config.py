import os
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT_DIR / "data"
INCIDENTS_DIR = DATA_DIR / "incidents"
LOGS_DIR = DATA_DIR / "logs"
RUNBOOKS_DIR = DATA_DIR / "runbooks"
DB_PATH = DATA_DIR / "signalops.db"
HISTORICAL_INCIDENTS_PATH = DATA_DIR / "historical_incidents.json"

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
MODEL_NAME = os.getenv("MODEL_NAME", "llama3.1")
APP_ENV = os.getenv("APP_ENV", "development")
