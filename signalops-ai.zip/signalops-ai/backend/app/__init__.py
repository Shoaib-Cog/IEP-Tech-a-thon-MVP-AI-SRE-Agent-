"""SignalOps AI application package."""
