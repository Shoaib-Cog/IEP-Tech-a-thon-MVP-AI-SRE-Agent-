from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class PagerDutyAlert(BaseModel):
    incident_id: str = Field(default="PD-0000")
    alert_name: str = Field(default="Unknown Alert")
    summary: str = Field(default="")
    service: str = Field(default="unknown-service")
    severity: str = Field(default="SEV-2")
    source: str = Field(default="pagerduty")


class InvestigationRequest(BaseModel):
    incident_id: Optional[str] = None
    alert_name: str = Field(default="Payment Service Degraded")
    summary: str = Field(default="Payment service degradation detected")
    service: str = Field(default="payment-service")
    severity: str = Field(default="SEV-1")
    source: str = Field(default="pagerduty")


class AgentResult(BaseModel):
    agent: str
    status: str
    summary: str
    details: Dict[str, Any] = Field(default_factory=dict)


class IncidentRecord(BaseModel):
    incident_id: str
    alert_name: str
    service: str
    severity: str
    investigation_status: str = "in_progress"
    root_cause: str = "pending"
    confidence: float = 0.0
    business_impact: str = "pending"
    recommended_actions: str = "pending"
    executive_summary: str = "pending"
    timeline: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
